IFT3913-TP1

Muxue GUO (20160375)
Joseph EL-SAYEGH (20110482)

Le lien vers notre repositoire: https://github.com/JosephSa98/IFT3913_Dev1.git


UTILISATION DU LOGICIEL:
1- Ouvrir le terminal et exécuter la commande:

    java -jar IFT3913_Dev1.jar [path vers le dossier/classe à analyser]

2- Pour les résultats, aller dans CSV/ pour trouver les fichiers .csv 
